ShotLattice sample exports

These three PNG files are actual outputs from the included fictional example, showing the three supported layouts. They are samples, not the full application.

Try the free limited demo and see the full product:
https://www.svensson.design/tools/shotlattice/

The demo supports one image, one language and one portrait format. The full version is a one-time purchase through Gumroad.
